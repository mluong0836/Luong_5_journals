var complaints = prompt("Please feel free to comment about any complaints that you have. Was it worth it to go to this page?");

if (complaints == "no") {
        document.write("You should learn to be more positive about getting jacked.<br>");
        document.write("<br>It's bound to happen again soon.<br>");
        document.write("<br> Thank you for your lovely criticism. We will try to resolve this conflict in our next madlib page.<br>");
    } else {
        document.write("YOU ARE SO <b>WELCOME</b></br>");
        document.write("Please feel free to wait for our next edition. We will email you a copy of the madlib because you're <br> one of our only gratifying customers.<br>");
    }



