document.getElementById("p2").style.color = "red";

document.write("This is how we math\ in <i>JavaScript</i>. <br>");


var k = prompt("Pick a number");
var r = prompt("Pick a number");
var d = k + r;
var num1 = parseInt(k);
/* We parseInt'ed so the variables would be treated as integers not strings */
var num2 = parseInt(r);
var num3 = num1 + num2;

document.write("<br> k is " + k + " r is " + r + " d is k + r and it's " + d + "<br>");
document.write("<br> multiplication:<br>");
document.write(k * r);
document.write("<br> division: <br>");
document.write(k / r);
document.write("<br> addition: <br>");
document.write(num1 + num2);
document.write("<br> subtract <br>");
document.write(k - r);
document.write("<br>This is num1 " + num1);
document.write("<br> This is num2 "  + num2);
num1++;
document.write("<br>This is num1 again " + num1 ++ + "<br>");
num2++;
document.write("<br>This is num2 again " + num2 + "<br>");
document.write("<br>This is num2 " + (++num2) + "<br>");

num1 = 42;

num1 +=5;
document.write(num1 + "<br>");
num1 -=5;
document.write(num1 + "<br>");
num1 /=5;
document.write(num1 + "<br>");

/* L337 h@x0r5 use conditionals */

if ( k == r) {
    document.writeln("<br> k and r are the same <br>");
} else if ( k < r) {
    document.write("<br> k is less than r.");
    document.write("<br> k and r are NOT the same <br>");
} else if (k > r) {
    document.write("<br> k is greater than r.");
    document.write("<br> k and r are NOT the same <br>");
} else {
    document.write("<br>This should never happen unless your're awesome like Micheal!");
}


















