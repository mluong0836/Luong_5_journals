var mainCanvas = document.querySelector("#myCanvas");
var mainContext = mainCanvas.getContext("2d");
 
var canvasWidth = mainCanvas.width;
var canvasHeight = mainCanvas.height;
var angle = 0;
var x = 9;
var y = 70;
var requestAnimationFrame = window.requestAnimationFrame ||
                            window.mozRequestAnimationFrame || 
                            window.webkitRequestAnimationFrame || 
                            window.msRequestAnimationFrame;

function drawCircle() {
    mainContext.fillRect(0, 0, canvasWidth, canvasHeight);
     
    // color in the background
    mainContext.fillStyle = "black";
    mainContext.fillRect(0, 0, canvasWidth, canvasHeight);
     
    // draw the circle
    mainContext.beginPath();
     
    var radius = 25 + 150 * Math.abs(Math.cos(angle));
    mainContext.arc(225, 225, radius, 0, Math.PI * 2, false);
    //mainContext.moveTo(50,50);
    //mainContext.lineTo(120,150);
    //mainContext.lineTo(0,180); 
    //mainContext.lineTo(120,210);
      
    mainContext.closePath();
     
    // color in the circle
  
    
    for (i = 0; i < 1; i++) {
        mainContext.beginPath();
        mainContext.fillStyle="pink";
        mainContext.arc(x, y, radius, 0, Math.PI * 2, false);
        //mainContext.arc(12 *i,12+i*41,5,0,2*Math.PI);
        mainContext.fill();
        mainContext.closePath();
        mainContext.rotate(60);
    }
    
       for (i = 0; i < 6; i++) {
        mainContext.beginPath();
        mainContext.fillStyle="orange";
        mainContext.arc(4, 5, radius, 0, Math.PI * 2, false);
        //mainContext.arc(12 *i,12+i*41,5,0,2*Math.PI);
        mainContext.fill();
        mainContext.closePath();
        mainContext.rotate(60);
        mainContext.translate(50, 60);
    }
    angle += Math.PI / 64;
    x += 5;
    y -= 1;
    mainContext.fillStyle = "#7CFC00";
    mainContext.fill();
    requestAnimationFrame(drawCircle);
    
    if(x > 40) {
        x -= 5;
    }
    
    if(y < 232) {
        y += 1;
    }
    
    if(x < 343) {
        x+=5;
    }
    
    if(y >223) {
        y-=5;
    }
}

drawCircle();

