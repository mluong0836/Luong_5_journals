/*var canvas;
var ctx;
var x = 450;
var y = 200;
var x1 = 450;
var y1 = 200;
var dx1 = 2;
var dy1 = 4;
var WIDTH = 900;
var HEIGHT = 900;


function rect(x,y,w,h) {
  ctx.beginPath();
  ctx.rect(x,y,w,h);
  ctx.closePath();
  ctx.fill();
}

function rect1(x1,y1,w1,h1) {
  ctx.beginPath();
  ctx.rect(x1,y1,w1,h1);
  ctx.closePath();
  ctx.fillStyle = "Red";
  ctx.fill();
}



function clear() {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
}

function init() {
  canvas = document.getElementById("myCanvas");
  ctx = canvas.getContext("2d");
  return setInterval(draw, 10);
}


function draw() {

  clear();
  ctx.fillStyle = "#FAF7F8";
  rect(0,0,WIDTH,HEIGHT);
  //ctx.fillStyle = "#444444";``
    for(i = 0; i < 50; i++) {
        
        rect1(x1, y1, 30, 30);
        x1 += 5; 
        y1 += 5;
    }

    // if (x1 + dx1 > WIDTH || x1 + dx1 < 0)
    // dx1 = -dx1;


    if (y1 + dy1 + 28 > HEIGHT || y1 + dy1 < 0) {
        dy1 = 0;
    }
    
  y1 += dy1;
    // x2 += dx2;
  // y2 += dy2;
        
}

init();
*/

var Animation = function(canvasID) {
    this.canvas = document.getElementById(canvasID);
    this.context = this.canvas.getContext("2d");
    this.t = 0;
    this.timeInterval = 0;
    this.startTime = 0;
    this.lastTime = 0;
    this.frame = 0;
    this.animating = false;
    
    window.requestAnimFrame = (function(callback) {
        return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame || 
        window.mozRequestAnimationFrame || 
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function(callback) {
            window.setTimeout(callback, 1000 / 60);
        };
    })();
};

Animation.prototype.getContext = function() {
    return this.context;
};

Animation.prototype.getCanvas = function() {
    return this.canvas;
};

Animation.prototype.clear = function() {
    this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
};

Animation.prototype.setDrawStage = function(func) {
    this.drawStage = func;
};

Animation.prototype.isAnimating = function() {
    return this.animating;
};

Animation.prototype.getFrame = function() {
    return this.frame;
};

Animation.prototype.start = function() {
    this.animating = true;
    var date = new Date();
    this.startTime = date.getTime();
    this.lastTime = this.startTime;
    
    if (this.drawStage !== undefined) {
        this.drawStage();
    }
    
    this.animationLoop();
};

Animation.prototype.stop = function() {
    this.animating = false;
};

Animation.prototype.getTimeInterval = function() {
    return this.timeInterval;
};

Animation.prototype.getTime = function() {
    return this.t;
};

Animation.prototype.getFps = function() {
    return this.timeInterval > 0 ? 1000 / this.timeInterval : 0;
};

Animation.prototype.animationLoop = function() {
    var that = this;
    
    this.frame++;
    var date = new Date();
    var thisTime = date.getTime();
    this.timeInterval = thisTime - this.lastTime;
    this.t += this.timeInterval;
    this.lastTime = thisTime;
    
    if (this.drawStage !== undefined) {
        this.drawStage();
    }
    
    if(this.animating) {
        requestAnimFrame(function() {
            that.animationLoop();
            
        });
    }
};