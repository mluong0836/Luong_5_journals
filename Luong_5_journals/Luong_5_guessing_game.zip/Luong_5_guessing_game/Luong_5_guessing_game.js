alert("Welcome to Micheal's wonderful guessing game!");
var player = prompt("What's your name?");
var magicnumber1 = Math.floor((Math.random() * 10) + 1);
var userguess1 = prompt(player + ", please pick a number between 0 and 10");

while(userguess1 != magicnumber1) {
     if (userguess1 > magicnumber1) {
         alert("Your number is too big!");
         userguess1 = prompt("Please pick another number from 0 and 10."); 
     } else if (userguess1 < magicnumber1) {
         alert("Your number is too small!");
         userguess1 = prompt("Please pick another number from 0 and 10."); 
     } else {
         alert("Congratulations " + player + ", the number " + userguess1 + " is the correct answer. ");
         confirm("Move on to level 2.");
     }
}

if(userguess1 == magicnumber1) {
    alert("Congratulations " + player + ", the number " + userguess1 + " is the correct answer. ");
    confirm("Move on to level 2.");
}

var magicnumber2 = Math.floor((Math.random() * 50) + 1);
alert(player + ", you are now at stage 2 of Micheal's Wonderful World of Guessing Games.");
var userguess2 = prompt(player + ", please pick a number from 0 to 50.");

while(userguess2 != magicnumber2) {
    if(userguess2 > magicnumber2) {
        alert("Your number is too big");
        userguess2 = prompt("Please pick another number from 0 to 50.");
    } else if (userguess2 < magicnumber2) {
        alert("Your number is to small!");
        userguess2 = prompt("Please pick a number between 0 and 50.");
    } else {
        alert("Congratulations " + player + ", the number " + userguess2 + " is correct."); 
        confirm("Move on to level 3");
    }   
}

if(userguess2 == magicnumber2){
    alert("Congratulations " + player + ", the number " + userguess2 + " is correct."); 
    confirm("Move on to level 3");
}

var magicnumber3 = Math.floor((Math.random() * 100) + 1);
var counter = 10;
rand1 = Math.floor((Math.random() * 100) + 1);
alert(player + ", you are now at stage 3 of Micheal's Wondeful Guessing Game.");
alert("This level is going to be extremely difficult because you have to guess a number from\
       0 to 100 in 10 tries.");
alert("GOOD LUCK!");
var userguess3 = prompt(player + ", please pick a number from 0 to 100."); 

while(userguess3 != magicnumber3) {
    if(userguess3 > magicnumber3) {
        alert("Your number is too big");
        counter--;
        alert("You now have " + counter + " tries.");
        if(counter < 1) {
            alert("You ran out of tries.");
            confirm("Try again");
            counter += 10;
            magicnumber3[rand1];
            userguess3 = prompt("Please pick another number between 0 and 100.");
        } else {
            userguess3 = prompt("Please pick another number between 0 and 100.");
        }
    } else if (userguess3 < magicnumber3) {
        alert("Your number is too small");
        counter--;
        alert("You now have " + counter + " tries left.");
        if (counter < 1) {
            alert("You ran out of tries.");
            confirm("Try again");
            counter += 10;
            magicnumber3[rand1];
            userguess3 = prompt("Please pick another number between 0 and 100.");
        } else {
            userguess3 = prompt("Please pick another number between 0 and 100.");
        }
    } else {
        alert("Congratulations " + player + ", the number " + userguess3 + " is correct.");
        confirm("Move on to level 4");
    }
}

if(userguess3 == magicnumber3) {
    alert("Congratulations " + player + ", the number " + userguess3 + " is correct.");
    confirm("Move on to level 4");
}

var magicnumber4 = Math.floor((Math.random() * 150) + 1) 
var counter2 = 7;
rand2 = Math.floor((Math.random() * 150) + 1);
alert(player + ", you are now at stage 4 of Micheal's Wondeful Guessing Game.");
alert("This level is going to be extremely difficult because you have to guess a number from\
       0 to 150 in 7 tries.");
alert("GOOD LUCK!");
var userguess4 = prompt(player + ", please pick a number from 0 to 150."); 

while(userguess4 != magicnumber4 && counter2 > 1) {
    if(userguess4 > magicnumber4) {
        alert("Your number is too big!");
        counter2--;
        alert("You now have " + counter2 + " tries left.");
        if (counter2 < 1){
            alert("You ran out of tries!!!");
            confirm("Try Again?");
            counter2 += 7;
            magicnumber4[rand2];
            userguess4 = prompt("Please pick another number between 0 and 150.");
        } else {
            userguess4 = prompt("Please pick another number between 0 and 150.");
        }
    } else if (userguess4 < magicnumber4) {
        alert("Your number is too small!");
        counter2--;
        alert("You now have " + counter2 + " tries left.");
        if (counter2 < 1) {
            alert("You ran out of tries!!!");
            confirm("Try Again?");
            counter2 += 7;
            magicnumber4[rand2];
            userguess4 = prompt("Please pick another number between 0 and 150.");
        } else {
            userguess4 = prompt("Please pick another number between 0 and 150.");
        }
    } else {
        alert("Congratulations " + player + ", the number " + userguess4 + " is correct.");
        confirm("Move on to level 5. THR HORROR!");
    }
}

if(userguess4 == magicnumber4) {
    alert("Congratulations " + player + ", the number " + userguess4 + " is correct.");
    confirm("Move on to level 5. THR HORROR!");
}

var magicnumber5 = Math.floor((Math.random() * 175) + 1);
var counter3 = 5;
rand3 = Math.floor((Math.random() * 175) + 1);
alert(player + ", you are at stage 5 of Micheal's Wonderful Guessing Game.");
alert("This level is known as the Terror for it will cause many OCD's freak out...");
alert("There will be 5 tries, but you now have to guess the correct answer from 175 choices. GOOD LUCK!");
var userguess5 = prompt(player + ", please pick a number from 0 to 175.");

while(userguess5 != magicnumber5) {
    if(userguess5 > magicnumber5) {
        alert("Your number is too big!");
        counter3--;
        alert("You now have " + counter3 + " tries left.");
        if(counter3 < 1) {
            alert("You ran out of tries!!!");
            confirm("Try Again?");
            counter3+=5;
            magicnumber5 = Math.floor((Math.random() * 175) + 1);
            userguess5 = prompt("Please pick another number between 0 and 175.");
        } else {
            userguess5 = prompt("Please pick another number between 0 and 175.");
        }
    } else if (userguess5 < magicnumber5) {
        alert("Your number is too small!");
        counter3--;
        alert("You now have " + counter3 + " tries left.");
          if(counter3 < 1) {
            alert("You ran out of tries!!!");
            confirm("Try Again?");
            counter3 += 5;
            magicnumber5 = Math.floor((Math.random() * 175) + 1);
            userguess5 = prompt("Please pick another number between 0 and 175.");
        } else {
            userguess5 = prompt("Please pick another number between 0 and 175.");
        }
    } else {
        alert("Congratulations " + player + ", the number " + userguess5 + " is correct.");
        alert("Congratulations, you finished all of the levels. Great Job.");
        alert("Here's something that you would enjoy, but first guess a numberfrom 0 to 10.");
    }
}

if(userguess5 == magicnumber5) {
    alert("Congratulations " + player + ", the number " + userguess5 + " is correct.");
    alert("Congratulations, you finished all of the levels. Great Job.");
    alert("Here's something that you would enjoy, but first guess a numberfrom 0 to 10.");
}
    

var joke = Math.floor((Math.random() * 10) + 1);
var hi = prompt("What's your number? 0 to 10.")

if(joke < 7){
    alert("TOO SMALL!");
    alert("That's what she said.");
} else {
    alert("TOO BIG!");
    alert("That's what she said!")
}

function playFunction() {
    location.reload();
}

function cancelFunction() {
    document.write("Thanks for playing!");
}































